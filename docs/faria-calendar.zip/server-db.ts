import fs from "fs";
import path from "path";
import crypto from "crypto";

const DB_FILE = path.join(process.cwd(), "db.json");
const ENCRYPTION_KEY_SECRET = process.env.JWT_SECRET || "faria-calendar-super-secret-key-12345";

// Interface Definitions
export interface User {
  id: string;
  email: string;
  name: string;
  picture?: string;
  viewer_tz: string;
  role: string; // 'you', 'manager', 'team'
  encrypted_refresh_token?: string;
}

export interface WorkHours {
  userId: string;
  segments: [number, number][]; // e.g. [[9, 12], [14, 18]]
}

export interface UserPreferences {
  userId: string;
  muted_titles: string[];
  muted_calendar_ids: string[];
  broadcast_threshold: number;
  only_accepted: boolean;
  hide_optional: boolean;
  working_hours_only: boolean;
}

export interface IncludedCalendar {
  calendarId: string;
  include: boolean;
  summary: string;
}

export interface RosterPerson {
  id: string;
  name: string;
  email: string;
  timezone: string;
  role: "manager" | "team";
  segments: [number, number][];
}

interface DatabaseSchema {
  users: { [id: string]: User };
  work_hours: { [userId: string]: WorkHours };
  preferences: { [userId: string]: UserPreferences };
  included_calendars: { [userId: string]: IncludedCalendar[] };
  roster: RosterPerson[];
}

// AES-256-CBC Encryption helpers for token-at-rest encryption
function getCipherKey(): Buffer {
  return crypto.createHash("sha256").update(ENCRYPTION_KEY_SECRET).digest();
}

export function encryptToken(token: string): string {
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv("aes-256-cbc", getCipherKey(), iv);
  let encrypted = cipher.update(token, "utf8", "hex");
  encrypted += cipher.final("hex");
  return iv.toString("hex") + ":" + encrypted;
}

export function decryptToken(encryptedData: string): string {
  try {
    const parts = encryptedData.split(":");
    if (parts.length !== 2) return "";
    const iv = Buffer.from(parts[0], "hex");
    const encryptedText = Buffer.from(parts[1], "hex");
    const decipher = crypto.createDecipheriv("aes-256-cbc", getCipherKey(), iv);
    let decrypted = decipher.update(encryptedText).toString();
    decrypted += decipher.final().toString();
    return decrypted;
  } catch (err) {
    console.error("Token decryption failed:", err);
    return "";
  }
}

// Initial Seed data containing standard global remote teammates
const DEFAULT_ROSTER: RosterPerson[] = [
  {
    id: "chloe-lon",
    name: "Chloe Stirling",
    email: "chloe@fariaedu.com",
    timezone: "Europe/London",
    role: "manager",
    segments: [[9, 12], [14, 17]], // Fragmented hours
  },
  {
    id: "kenji-tok",
    name: "Kenji Sato",
    email: "kenji@fariaedu.com",
    timezone: "Asia/Tokyo",
    role: "team",
    segments: [[9, 18]],
  },
  {
    id: "aarav-blr",
    name: "Aarav Nair",
    email: "aarav@fariaedu.com",
    timezone: "Asia/Kolkata",
    role: "team",
    segments: [[10, 13], [15, 19]], // Fragmented hours
  },
  {
    id: "sarah-nyc",
    name: "Sarah Jenkins",
    email: "sarah@fariaedu.com",
    timezone: "America/New_York",
    role: "team",
    segments: [[9, 17]],
  },
  {
    id: "alex-sfo",
    name: "Alex Rivera",
    email: "alex@fariaedu.com",
    timezone: "America/Los_Angeles",
    role: "team",
    segments: [[9, 17]],
  },
];

// Read DB from local JSON file
export function readDB(): DatabaseSchema {
  try {
    if (!fs.existsSync(DB_FILE)) {
      const initial: DatabaseSchema = {
        users: {},
        work_hours: {},
        preferences: {},
        included_calendars: {},
        roster: DEFAULT_ROSTER,
      };
      fs.writeFileSync(DB_FILE, JSON.stringify(initial, null, 2), "utf8");
      return initial;
    }
    const content = fs.readFileSync(DB_FILE, "utf8");
    const parsed = JSON.parse(content) as DatabaseSchema;
    // Backfill roster if missing or empty
    if (!parsed.roster || parsed.roster.length === 0) {
      parsed.roster = DEFAULT_ROSTER;
    }
    return parsed;
  } catch (err) {
    console.error("Error reading database file, returning default:", err);
    return {
      users: {},
      work_hours: {},
      preferences: {},
      included_calendars: {},
      roster: DEFAULT_ROSTER,
    };
  }
}

// Write DB to local JSON file safely
export function writeDB(data: DatabaseSchema): void {
  try {
    const tempFile = DB_FILE + ".tmp";
    fs.writeFileSync(tempFile, JSON.stringify(data, null, 2), "utf8");
    fs.renameSync(tempFile, DB_FILE);
  } catch (err) {
    console.error("Error saving database file:", err);
  }
}

// CRUD Operations Convenience Helpers
export function getUser(id: string): User | undefined {
  const db = readDB();
  return db.users[id];
}

export function getUserByEmail(email: string): User | undefined {
  const db = readDB();
  return Object.values(db.users).find((u) => u.email.toLowerCase() === email.toLowerCase());
}

export function saveUser(user: User): void {
  const db = readDB();
  db.users[user.id] = user;
  writeDB(db);
}

export function getWorkHours(userId: string): WorkHours {
  const db = readDB();
  const existing = db.work_hours[userId];
  if (existing) return existing;

  // Default segmented working hours
  return {
    userId,
    segments: [[9, 17]],
  };
}

export function saveWorkHours(userId: string, segments: [number, number][]): void {
  const db = readDB();
  db.work_hours[userId] = { userId, segments };
  writeDB(db);
}

export function getPreferences(userId: string): UserPreferences {
  const db = readDB();
  const existing = db.preferences[userId];
  if (existing) return existing;

  return {
    userId,
    muted_titles: ["Review", "Standup Sync", "Focus", "Catch Up"],
    muted_calendar_ids: [],
    broadcast_threshold: 15,
    only_accepted: false,
    hide_optional: false,
    working_hours_only: false,
  };
}

export function savePreferences(userId: string, prefs: Partial<UserPreferences>): UserPreferences {
  const db = readDB();
  const current = getPreferences(userId);
  const updated = { ...current, ...prefs };
  db.preferences[userId] = updated;
  writeDB(db);
  return updated;
}

export function getIncludedCalendars(userId: string): IncludedCalendar[] {
  const db = readDB();
  return db.included_calendars[userId] || [];
}

export function saveIncludedCalendars(userId: string, calendars: IncludedCalendar[]): void {
  const db = readDB();
  db.included_calendars[userId] = calendars;
  writeDB(db);
}

export function getRoster(): RosterPerson[] {
  const db = readDB();
  return db.roster;
}

export function addRosterPerson(person: Omit<RosterPerson, "id">): RosterPerson {
  const db = readDB();
  const newPerson: RosterPerson = {
    ...person,
    id: "roster-" + Math.random().toString(36).substr(2, 9),
  };
  db.roster.push(newPerson);
  writeDB(db);
  return newPerson;
}

export function updateRosterPerson(id: string, updated: Partial<RosterPerson>): void {
  const db = readDB();
  const index = db.roster.findIndex((p) => p.id === id);
  if (index !== -1) {
    db.roster[index] = { ...db.roster[index], ...updated } as RosterPerson;
    writeDB(db);
  }
}

export function deleteRosterPerson(id: string): void {
  const db = readDB();
  db.roster = db.roster.filter((p) => p.id !== id);
  writeDB(db);
}
