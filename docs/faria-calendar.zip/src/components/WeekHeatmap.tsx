import React, { useState } from "react";
import { WeekDaySummary } from "../types";
import { Sun, AlertCircle } from "lucide-react";

interface WeekHeatmapProps {
  weekData: WeekDaySummary[] | null;
  selectedIds: string[];
  activeDate: string;
  openDays: string[];
  onToggleDay: (date: string) => void;
  workingHoursOnly: boolean;
}

export default function WeekHeatmap({
  weekData,
  selectedIds,
  activeDate,
  openDays,
  onToggleDay,
  workingHoursOnly,
}: WeekHeatmapProps) {
  const [hoveredCell, setHoveredCell] = useState<{ dayIndex: number; hour: number } | null>(null);

  if (!weekData || weekData.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-48 border border-white/5 bg-slate-900/40 backdrop-blur rounded-2xl text-slate-400 p-6 text-center">
        <Sun className="h-8 w-8 text-indigo-400 animate-spin mb-3" />
        <p className="text-sm font-medium">Scanning week availability matrix...</p>
      </div>
    );
  }

  // Hours to render: 0 to 23, or 8 to 22 if working hours only
  const startHour = workingHoursOnly ? 8 : 0;
  const endHour = workingHoursOnly ? 21 : 23;
  const totalHours = endHour - startHour + 1;
  const hoursRange = Array.from({ length: totalHours }, (_, i) => startHour + i);

  // Map decimal hour to AM_PM label
  const formatHourLabel = (h: number): string => {
    return String(h).padStart(2, "0") + ":00";
  };

  // Get cell coverage styling with lighter weekend visual indicator
  const getCellColorClass = (freeCount: number, total: number, isWeekend: boolean) => {
    if (total === 0) return isWeekend ? "bg-white/[0.02] text-slate-700" : "bg-white/5 text-slate-600";
    if (freeCount === 0) {
      return isWeekend
        ? "bg-slate-900/10 hover:bg-slate-800/20 opacity-30 border border-transparent"
        : "bg-slate-900/40 hover:bg-slate-800/50";
    }
    
    const ratio = freeCount / total;
    if (ratio === 1) {
      // Everyone free - full glowing green
      return isWeekend
        ? "bg-[#34D399]/70 shadow-[0_0_8px_rgba(52,211,153,0.25)] text-black font-semibold"
        : "bg-[#34D399] shadow-[0_0_12px_rgba(52,211,153,0.4)] text-black font-semibold";
    }
    if (ratio >= 0.75) {
      return isWeekend 
        ? "bg-emerald-500/50 border border-emerald-400/10 text-white/90" 
        : "bg-emerald-500/70 border border-emerald-400/20 text-white";
    }
    if (ratio >= 0.5) {
      return isWeekend 
        ? "bg-emerald-600/25 text-emerald-200/80" 
        : "bg-emerald-600/40 text-emerald-100";
    }
    if (ratio >= 0.25) {
      return isWeekend 
        ? "bg-cyan-500/10 text-cyan-400/80" 
        : "bg-cyan-500/15 text-cyan-300";
    }
    return isWeekend 
      ? "bg-amber-500/5 text-amber-300/70" 
      : "bg-amber-500/10 text-amber-200";
  };

  return (
    <div className="border border-white/8 bg-[#141b30]/55 backdrop-blur-md rounded-2xl p-5 shadow-xl transition-all duration-300">
      <div className="flex items-center justify-between mb-4 border-b border-white/5 pb-3">
        <div>
          <h3 className="font-display text-base font-semibold text-[#EAF0FF] tracking-wide">
            7-Day Overlap Heatmap
          </h3>
          <p className="text-xs text-[#6B779C] mt-0.5">
            Bright green cells indicate slots where most of your {selectedIds.length} chosen teammates are free.
          </p>
        </div>
        <div className="flex items-center gap-1.5 text-[10px] text-amber-300 bg-amber-400/5 hover:bg-amber-400/10 border border-amber-400/10 px-2.5 py-1 rounded-full select-none">
          <AlertCircle className="h-3 w-3" />
          <span>Viewer Zone Clock</span>
        </div>
      </div>

      <div className="grid grid-cols-[auto_repeat(7,1fr)] gap-1.5 overflow-x-auto select-none no-scrollbar">
        {/* Hour Header cell */}
        <div className="w-12 text-right pr-2 text-[10px] text-[#6B779C] font-semibold mt-10">
          Time
        </div>

        {/* Day Column Headers */}
        {weekData.map((day, idx) => {
          const isToday = day.date === activeDate;
          const isOpen = openDays.includes(day.date);
          const isWeekend = day.dayName === "Sat" || day.dayName === "Sun";
          return (
            <button
              key={day.date}
              onClick={() => onToggleDay(day.date)}
              className={`flex flex-col items-center justify-center p-2 rounded-xl transition-all group ${
                isToday 
                  ? "bg-[#6D8BFF]/10 border border-[#6D8BFF]/35 text-[#EAF0FF]" 
                  : isOpen 
                    ? "bg-white/5 border border-white/10 text-[#AEB9D6]"
                    : `border border-transparent text-[#AEB9D6] ${isWeekend ? "bg-slate-900/10 opacity-70 hover:opacity-100 hover:bg-white/5" : "hover:bg-white/5"}`
              }`}
            >
               <span className="text-[10px] uppercase tracking-wider font-bold text-[#6B779C]">
                {day.dayName}
              </span>
              <span className="text-sm font-display font-medium leading-none mt-1">
                {day.formattedDate.split(" ")[1]}
              </span>
              <span className={`text-[9px] mt-1.5 px-1.5 py-0.5 rounded-full ${
                isOpen 
                  ? "bg-indigo-500/20 text-[#6D8BFF] border border-indigo-500/20" 
                  : "bg-slate-900/50 text-[#6B779C] group-hover:text-[#AEB9D6]"
              }`}>
                {isOpen ? "Open" : "View"}
              </span>
            </button>
          );
        })}

        {/* Row data: Hours */}
        {hoursRange.map((hr) => (
          <React.Fragment key={hr}>
            {/* Hour Label Column */}
            <div className="flex items-center justify-end pr-2 text-[10px] font-mono font-medium text-[#6B779C] h-7">
              {formatHourLabel(hr)}
            </div>

            {/* Cell Columns per day */}
            {weekData.map((day, dIdx) => {
              const freeCount = day.hourlyFreeCounts[hr] || 0;
              const total = selectedIds.length;
              const isHovered = hoveredCell?.dayIndex === dIdx && hoveredCell?.hour === hr;
              const isWeekend = day.dayName === "Sat" || day.dayName === "Sun";

              return (
                <div
                  key={day.date + "-" + hr}
                  onMouseEnter={() => setHoveredCell({ dayIndex: dIdx, hour: hr })}
                  onMouseLeave={() => setHoveredCell(null)}
                  onClick={() => onToggleDay(day.date)}
                  className={`h-7 rounded-md cursor-pointer flex items-center justify-center text-[9px] font-mono transition-all duration-150 ${
                    isHovered ? "scale-105 z-10 brightness-110" : ""
                  } ${getCellColorClass(freeCount, total, isWeekend)}`}
                  title={`${day.dayName} ${formatHourLabel(hr)}: ${freeCount}/${total} free`}
                >
                  {total > 0 && (
                    <span className="opacity-80 scale-90">
                      {freeCount}
                    </span>
                  )}
                </div>
              );
            })}
          </React.Fragment>
        ))}
      </div>

      {hoveredCell !== null && weekData[hoveredCell.dayIndex] && (
        <div className="mt-4 flex items-center justify-between text-xs text-[#AEB9D6] bg-[#070A14] border border-white/5 rounded-xl px-4 py-2.5">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#34D399]" />
            <span>
              <strong>
                {weekData[hoveredCell.dayIndex].dayName} {formatHourLabel(hoveredCell.hour)}
              </strong>
              : {weekData[hoveredCell.dayIndex].hourlyFreeCounts[hoveredCell.hour]} of {selectedIds.length} people free on their local clock.
            </span>
          </div>
          <span className="text-[10px] text-[#6B779C] italic">Click day header to details</span>
        </div>
      )}
    </div>
  );
}
